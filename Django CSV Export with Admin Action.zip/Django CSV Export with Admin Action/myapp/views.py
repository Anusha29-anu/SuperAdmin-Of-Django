import csv
from django.http import HttpResponse
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render
from .models import Employee


def index(request):
    """
    Simple index view for the application.
    """
    return render(request, 'myapp/index.html')


@staff_member_required
def export_employees_csv(request):
    """
    Export all employees data to a CSV file.
    This view can be called directly or through admin actions.
    """
    # Create the HttpResponse object with appropriate CSV header
    response = HttpResponse(
        content_type='text/csv',
        headers={'Content-Disposition': 'attachment; filename="employees_export.csv"'},
    )
    
    # Create CSV writer
    writer = csv.writer(response)
    
    # Write CSV header
    writer.writerow([
        'ID',
        'First Name',
        'Last Name',
        'Email',
        'Phone',
        'Department',
        'Position',
        'Salary',
        'Hire Date',
        'Status',
        'Created At',
        'Updated At'
    ])
    
    # Write data rows
    employees = Employee.objects.all().order_by('id')
    for employee in employees:
        writer.writerow([
            employee.id,
            employee.first_name,
            employee.last_name,
            employee.email,
            employee.phone,
            employee.get_department_display_name(),
            employee.position,
            employee.salary,
            employee.hire_date.strftime('%Y-%m-%d') if employee.hire_date else '',
            employee.get_status_display(),
            employee.created_at.strftime('%Y-%m-%d %H:%M:%S') if employee.created_at else '',
            employee.updated_at.strftime('%Y-%m-%d %H:%M:%S') if employee.updated_at else '',
        ])
    
    return response


@staff_member_required
def export_filtered_employees_csv(request, queryset=None):
    """
    Export filtered employees data to CSV.
    This function can be used by admin actions with a specific queryset.
    """
    if queryset is None:
        queryset = Employee.objects.all()
    
    # Create the HttpResponse object with appropriate CSV header
    response = HttpResponse(
        content_type='text/csv',
        headers={'Content-Disposition': 'attachment; filename="filtered_employees_export.csv"'},
    )
    
    # Create CSV writer
    writer = csv.writer(response)
    
    # Write CSV header
    writer.writerow([
        'ID',
        'Full Name',
        'Email',
        'Phone',
        'Department',
        'Position',
        'Salary',
        'Hire Date',
        'Status'
    ])
    
    # Write data rows for filtered queryset
    for employee in queryset:
        writer.writerow([
            employee.id,
            employee.full_name,
            employee.email,
            employee.phone,
            employee.get_department_display_name(),
            employee.position,
            f"${employee.salary:,.2f}",
            employee.hire_date.strftime('%Y-%m-%d') if employee.hire_date else '',
            employee.get_status_display(),
        ])
    
    return response