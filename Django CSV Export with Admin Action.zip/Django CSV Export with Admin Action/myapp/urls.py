from django.urls import path
from . import views

app_name = 'myapp'

urlpatterns = [
    path('', views.index, name='index'),
    path('export/employees/', views.export_employees_csv, name='export_employees_csv'),
]