import csv
from django.contrib import admin
from django.http import HttpResponse
from django.urls import path
from django.shortcuts import redirect
from django.contrib import messages
from .models import Employee
from .views import export_employees_csv


def export_selected_employees_csv(modeladmin, request, queryset):
    """
    Custom admin action to export selected employees to CSV.
    """
    # Create the HttpResponse object with appropriate CSV header
    response = HttpResponse(
        content_type='text/csv',
        headers={'Content-Disposition': 'attachment; filename="selected_employees.csv"'},
    )
    
    # Create CSV writer
    writer = csv.writer(response)
    
    # Write CSV header
    writer.writerow([
        'ID',
        'Full Name',
        'Email',
        'Phone',
        'Department',
        'Position',
        'Salary',
        'Hire Date',
        'Status'
    ])
    
    # Write data rows for selected employees
    for employee in queryset:
        writer.writerow([
            employee.id,
            employee.full_name,
            employee.email,
            employee.phone,
            employee.get_department_display_name(),
            employee.position,
            f"${employee.salary:,.2f}",
            employee.hire_date.strftime('%Y-%m-%d') if employee.hire_date else '',
            employee.get_status_display(),
        ])
    
    messages.success(request, f'Successfully exported {queryset.count()} employees to CSV.')
    return response


def export_all_employees_csv_action(modeladmin, request, queryset):
    """
    Custom admin action to export ALL employees to CSV (ignores selection).
    """
    return export_employees_csv(request)


# Set display names for the actions
export_selected_employees_csv.short_description = "Export selected employees to CSV"
export_all_employees_csv_action.short_description = "Export ALL employees to CSV"


@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    """
    Enhanced Django admin interface for Employee model with CSV export functionality.
    """
    list_display = [
        'id',
        'first_name',
        'last_name',
        'email',
        'department',
        'position',
        'salary',
        'status',
        'hire_date'
    ]
    
    list_filter = [
        'department',
        'status',
        'hire_date',
        'created_at'
    ]
    
    search_fields = [
        'first_name',
        'last_name',
        'email',
        'position'
    ]
    
    list_editable = ['status']
    
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('Personal Information', {
            'fields': ('first_name', 'last_name', 'email', 'phone')
        }),
        ('Employment Details', {
            'fields': ('department', 'position', 'salary', 'hire_date', 'status')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    # Add custom actions to the admin
    actions = [
        export_selected_employees_csv,
        export_all_employees_csv_action,
    ]
    
    def get_urls(self):
        """
        Add custom URLs to the admin for direct CSV export.
        """
        urls = super().get_urls()
        custom_urls = [
            path('export-csv/', self.admin_site.admin_view(self.export_csv_view), name='employee_export_csv'),
        ]
        return custom_urls + urls
    
    def export_csv_view(self, request):
        """
        Custom view for CSV export accessible via URL.
        """
        return export_employees_csv(request)
    
    def changelist_view(self, request, extra_context=None):
        """
        Override changelist view to add custom context for CSV export button.
        """
        extra_context = extra_context or {}
        extra_context['csv_export_url'] = 'export-csv/'
        return super().changelist_view(request, extra_context)


# Customize admin site headers
admin.site.site_header = "Employee Management System"
admin.site.site_title = "EMS Admin"
admin.site.index_title = "Welcome to Employee Management System"